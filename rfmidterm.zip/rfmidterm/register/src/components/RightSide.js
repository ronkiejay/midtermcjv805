import React from 'react'

const RightSide = ({details, total}) => {
    return (
        <div class="right">
            <p id="text1">Number Selected: {details}</p>
            <br/><br/><br/><br/><br/>
            <br/><br/><br/><br/><br/>
            <br/><br/><br/><br/><br/>
            <br/><br/><br/><br/><br/>
            <br/><br/><br/>
            <p id="totaltext">Total: ${total}</p>
   
        
        </div>
    )
}

export default RightSide
