import React from 'react'

const Header = () => {
    return (
        <div id="upper">
            <header>
                <h1>WHE WHE on D'Avenue</h1>
            </header>
        </div>
    )
}

export default Header
