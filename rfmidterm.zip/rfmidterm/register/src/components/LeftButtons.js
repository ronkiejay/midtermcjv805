import React from 'react'

const LeftButtons = ({amount}) => {
    return (
        <div>
            <button id="button1" type="button" className="dollar1">${amount}</button> 
        </div>
    )
}

export default LeftButtons
