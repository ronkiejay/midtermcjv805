import React from 'react'
import LeftButtons from "./LeftButtons"
import lotoImage from "../img/lotto.jpg";

const LeftSide = () => {
    return (
        <div id="allbuttons">
            <div >
                <img src={lotoImage} id="lottoImg" alt=""/>
               
            </div >
            <div className="gridbuttons">
                <div id="buttons">
                    <LeftButtons amount={1} />
                    <LeftButtons amount={10} />
                </div>
                <div id="buttons">
                    <LeftButtons amount={5} />
                    <LeftButtons amount={20} /> 
                </div>
            </div>
        </div>
    )
}

export default LeftSide
