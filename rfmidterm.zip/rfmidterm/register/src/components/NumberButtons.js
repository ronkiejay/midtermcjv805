import React from 'react'

import '../App.css';


const NumberButtons = ({value}) => {

    const changeColor = () =>{
            alert("changeColor")
        }
    
  

    return (
        <div>
        
            <button id="button5" type="button" className="eachbutton" onClick={changeColor}> {value} </button>
        </div>
    )

}
export default NumberButtons
