import React from 'react'
import NumberButtons from "./NumberButtons"

const Middle = () => {
    
    return (

        <div>
        
            <div class="middleColumn" >
                <div>
                    <NumberButtons value={1}/>
                    <NumberButtons value={2}/>
                    <NumberButtons value={3}/>
                    <NumberButtons value={4}/>  
                </div>
                <div>
                    <NumberButtons value={5}/>
                    <NumberButtons value={6}/>
                    <NumberButtons value={7}/>
                    <NumberButtons value={8}/>   
                </div>
                <div>
                    <NumberButtons value={9}/>
                    <NumberButtons value={10}/>
                    <NumberButtons value={11}/>
                    <NumberButtons value={12}/>   
                </div>
                <div>
                    <NumberButtons value={13}/>
                    <NumberButtons value={14}/>
                    <NumberButtons value={15}/>
                    <NumberButtons value={16}/>   
                </div>
                <div>
                    <NumberButtons value={17}/>
                    <NumberButtons value={18}/>
                    <NumberButtons value={19}/>
                    <NumberButtons value={20}/>   
                </div>

            </div>
            <div id="cash">
                    <button id="button6" type="button" className="eachbutton"> Cash </button>
                    <button id="button6" type="button" className="eachbutton"> Clear </button>
            </div>
            

            {/* {buttons.map((button)=>(<Buttons id={button.id} key={button.id} value={button.value}/>))} */}
            
            
        </div>
       
    )
}

export default Middle
